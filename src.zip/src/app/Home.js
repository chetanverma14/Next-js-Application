import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { searchGiphy } from '../lib/giphy';
import GiphyResults from '../components/GiphyResults';

const Home = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const { data: session } = useSession();

  const handleSearch = async () => {
    const data = await searchGiphy(query);
    setResults(data);
  };

  return (
    <div>
      <h1>Welcome to GIPHY Search</h1>
      {session ? (
        <div>
          <p>Hello, {session.user.name}!</p>
          <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} />
          <button onClick={handleSearch}>Search GIPHY</button>
          <GiphyResults results={results} />
        </div>
      ) : (
        <p>Please sign in to use the GIPHY search feature.</p>
      )}
    </div>
  );
};

export default Home;
