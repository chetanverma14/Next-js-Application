import React from 'react';

const GiphyResults = ({ results }) => {
  return (
    <div>
      <h2>GIPHY Results</h2>
      <ul>
        {results.map((result) => (
          <li key={result.id}>
            <img src={result.images.fixed_height.url} alt={result.title} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default GiphyResults;
